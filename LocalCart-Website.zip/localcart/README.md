# LocalCart — Art, Craft & Culture Shop

LocalCart is a responsive front-end online shop concept celebrating art, crafts, and culture-led design in Uganda. Built with plain HTML, CSS, and JavaScript.

## Features
- Editorial, warm and handcrafted visual identity
- Product grid with search, category filtering, and sorting
- Shopping bag with quantity controls, remove item, subtotal and total
- Demo checkout form (no payments or real orders)
- LocalStorage cart persistence
- Responsive layout for mobile and desktop
- UGX prices
- No framework, build step, API key, or paid hosting required

## Publish free with GitHub Pages from your phone
1. Open https://github.com and sign in.
2. Create a **Public** repository named `localcart`.
3. In the repository, select **Add file → Upload files**.
4. Upload `index.html` from this folder and commit the change.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/(root)`, then Save.
8. Wait a few minutes. The URL will look like `https://YOUR-USERNAME.github.io/localcart/`.

If Settings → Pages is hard to find on mobile, open GitHub in your browser and turn on **Desktop site**.

## Important demo notes
- Products and prices are sample content for a student project, not verified live inventory or actual seller listings.
- Checkout is a front-end demonstration only. It does not collect payment or send orders to a shop owner.
- Product photography is loaded from Unsplash URLs, so images require an internet connection.
- The email address in the footer uses the reserved `.example` domain and is a placeholder, not a real support inbox.
- Before using this as a real business, replace sample products with real maker-approved items, confirm prices and delivery terms, and integrate secure order handling and a trusted payment provider.
